#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESPAsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <LittleFS.h>

// Motor A pins
int motor1Pin1 = 12; 
int motor1Pin2 = 14; 
int enable1Pin = 13; 

// Motor B pins
int motor2Pin1 = 5; 
int motor2Pin2 = 4; 
int enable2Pin = 0; 

// Ultrasonic Sensor pins
const int trigPin = 2; // GPIO2 (D4 on some ESP8266 boards)
const int echoPin = 15; // GPIO15 (D8 on some ESP8266 boards)

// Buzzer pin
const int buzzerPin = 16; // GPIO16 (D0 on some ESP8266 boards)

// Threshold distance in cm
const int thresholdDistance = 30; // Updated to 30 cm

// Replace with your network credentials
const char* ssid = "Nothing Phone (1)";
const char* password = "nothing@1";

// Create AsyncWebServer object on port 80
AsyncWebServer server(80);
bool objectDetected = false;

// Initialize LittleFS
void initFS() {
  if (!LittleFS.begin()) {
    Serial.println("An error has occurred while mounting LittleFS");
  } else {
    Serial.println("LittleFS mounted successfully");
  }
}

void initWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.println("Connecting to WiFi ..");
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    Serial.print('.');
    delay(1000);
    attempts++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("Connected to WiFi");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("Failed to connect to WiFi");
  }
}

void initUltrasonic() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
}

void initBuzzer() {
  pinMode(buzzerPin, OUTPUT);
  digitalWrite(buzzerPin, LOW); // Ensure buzzer is off initially
}

// Function to measure distance
long getDistance() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  long duration = pulseIn(echoPin, HIGH);
  if (duration == 0) {
    Serial.println("No echo received");
    return -1; // No echo received
  }
  // Convert the duration to distance in cm
  long distance = duration * 0.034 / 2;
  return distance;
}

void moveForward() {
  Serial.println("Moving Forward");
  digitalWrite(enable1Pin, HIGH);
  digitalWrite(motor1Pin1, LOW);
  digitalWrite(motor1Pin2, HIGH);
  digitalWrite(enable2Pin, HIGH);
  digitalWrite(motor2Pin1, LOW);
  digitalWrite(motor2Pin2, HIGH);
}

void moveBackward() {
  Serial.println("Moving Backward");
  digitalWrite(enable1Pin, HIGH);
  digitalWrite(motor1Pin1, HIGH);
  digitalWrite(motor1Pin2, LOW);
  digitalWrite(enable2Pin, HIGH);
  digitalWrite(motor2Pin1, HIGH);
  digitalWrite(motor2Pin2, LOW);
}

void stopMotors() {
  digitalWrite(enable1Pin, LOW);
  digitalWrite(motor1Pin1, LOW);
  digitalWrite(motor1Pin2, LOW);
  digitalWrite(enable2Pin, LOW);
  digitalWrite(motor2Pin1, LOW);
  digitalWrite(motor2Pin2, LOW);
}

void activateSiren() {
  for (int i = 1000; i < 2000; i += 50) {
    tone(buzzerPin, i);
    delay(10);
  }
  for (int i = 2000; i > 1000; i -= 50) {
    tone(buzzerPin, i);
    delay(10);
  }
}

void deactivateBuzzer() {
  noTone(buzzerPin);
}

void stopAll() {
  stopMotors();
  activateSiren();
}

void setup() {
  Serial.begin(115200);

  // Set motor pins as outputs
  pinMode(motor1Pin1, OUTPUT);
  pinMode(motor1Pin2, OUTPUT);
  pinMode(enable1Pin, OUTPUT);
  pinMode(motor2Pin1, OUTPUT);
  pinMode(motor2Pin2, OUTPUT);
  pinMode(enable2Pin, OUTPUT);

  initWiFi();
  initFS();
  initUltrasonic();
  initBuzzer();

  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(LittleFS, "/index.html", "text/html");
  });

  server.serveStatic("/", LittleFS, "/");

  server.on("/forward", HTTP_GET, [](AsyncWebServerRequest *request) {
    moveForward();
    request->send(LittleFS, "/index.html", "text/html", false);
  });

  server.on("/backward", HTTP_GET, [](AsyncWebServerRequest *request) {
    moveBackward();
    request->send(LittleFS, "/index.html", "text/html", false);
  });

  server.on("/stop", HTTP_GET, [](AsyncWebServerRequest *request) {
    stopMotors();
    request->send(LittleFS, "/index.html", "text/html", false);
  });

  server.on("/object-detected", HTTP_GET, [](AsyncWebServerRequest *request) {
    String json = "{\"detected\": " + String(objectDetected ? "true" : "false") + "}";
    request->send(200, "application/json", json);
  });

  server.begin();
}

void loop() {
  // Continuously monitor the distance
  long distance = getDistance();
  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  if (distance > 0 && distance <= thresholdDistance) {
    Serial.println("Object detected! Stopping motors and activating buzzer.");
    stopAll();
    objectDetected = true;
  } else {
    objectDetected = false;
    deactivateBuzzer();
  }

  delay(100); // Adjust delay as needed
}